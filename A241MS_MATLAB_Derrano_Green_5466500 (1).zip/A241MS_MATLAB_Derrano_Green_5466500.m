% Begin
clear
clc

% 1.1 Read Velocity.txt file
file = fopen('velocity.txt');
format = '%f';
vel = fscanf(file,format);

% 1.2 Calculate acceleration

acc = gradient(vel,0.5);

% 1.3 Plot Velocity & Acceleration

T = length(vel) - 1;

t = 0 : 0.5 : 0.5 * T;


plot( t, vel,'-r', 'LineWidth',2)
xlabel('Time, s')
ylabel('Velocity, ms^-^1')
title('Velocity vs Acceleration')
hold on

yyaxis right
plot(t, acc, '-og', 'LineWidth', 1)
ylabel ('Acceleration (ms^-^2)')
legend ('velocity, ms^-^1', 'acceleration, ms^-^2')
legend('Location','eastoutside')
hold off
cla reset

% 1.4 apply curve fitting

vel_2nd = polyfit(t,vel,2);
smooth_vel = polyval(vel_2nd, t);

% 1.5 calculate smooth 2nd order acceleration

acc_2 = gradient(smooth_vel,0.5);


% 1.6 plot vel, acc & 2nd order acc
yyaxis right
plot(t, acc, '--g',t, acc_2, '-m','LineWidth',1.5)
ylabel ('Acceleration (ms^-^2)')
xlabel('Time, s')
hold off
yyaxis left
plot(t,vel)
ylabel('Velocity, ms^-^1')
legend ('velocity, ms^-^1', 'acceleration, ms^-^2', '2^n^d order acceleration')
legend('Location','eastoutside')
title('Velocity, Acceleration & smoothed acceleration vs Time')

s = sprintf('y = (%.1f) x + (%.1f)',vel_2nd(1),vel_2nd(2));
text(5,315,s)
cla reset

% 1.7 apply curve fitting 4th order
vel_4th = polyfit(t,vel,4);
smooth_v4th = polyval(vel_4th, t);

% 1.8 Calculate smoothed 4th order acc
acc_4 = gradient(smooth_v4th, 0.5);

% 1.9 Plot vel, acc, smooth 4th order acc
yyaxis left
plot(t,vel)
ylabel('Velocity, ms^-^1')
hold on
yyaxis right
plot(t,acc,'-.g', t,acc_4)
ylabel ('Acceleration (ms^-^2)')
legend ('velocity, ms^-^1', 'acceleration, ms^-^2', '4^t^h order acceleration, ms^-^2')
legend('Location','eastoutside')
title('Velocity, Acceleration & smoothed 4^t^h order acceleration vs Time')
hold off
cla reset

% 1.95 calculate smoothed 5th, 7th & 9th order accelerations
vel_5th = polyfit(t,vel,5);
smooth_v5th = polyval(vel_5th, t);
acc_5 = gradient(smooth_v5th, 0.5);

vel_7th = polyfit(t,vel,7);
smooth_v7th = polyval(vel_7th, t);
acc_7 = gradient(smooth_v7th, 0.5);

vel_9 = polyfit(t,vel,9);
smooth_v9 = polyval(vel_9, t);
acc_9 = gradient(smooth_v9, 0.5);

% 1.10 2nd order and 4th order accelerations' analysis

hold on
plot(t,acc,'--c' ,t,acc_2, t,acc_4)
ylabel ('Acceleration (ms^-^2)')
xlabel('Time, s')
title('Acceleration, smoothed 2^n^d & 4^t^h order accelerations vs Time')
legend ( 'acceleration, ms^-^2', '2^n^d order acceleration, ms^-^2', '4^t^h order acceleration, ms^-^2')
legend('Location','eastoutside')
hold off
cla reset
hold on
plot(t,acc,'-.c' ,t,acc_5,'-*y' ,t,acc_7, '-k', t,acc_9, '-m')
hold off
title('Acceleration, smoothed 5^t^h, 7^t^h & 9^t^h order accelerations vs Time')
legend ( 'acceleration, ms^-^2', '5^t^h order acceleration, ms^-^2', '7^t^h order acceleration, ms^-^2', '9^t^h order acceleration, ms^-^2')
legend('Location','eastoutside')
ylabel ('Acceleration (ms^-^2)')
xlabel('Time, s')
cla reset
